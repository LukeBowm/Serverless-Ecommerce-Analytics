import json
import boto3
import os

# Initialize EventBridge client
events = boto3.client('events')
EVENT_BUS_NAME = 'default'  # Use the default event bus or specify a custom one

def lambda_handler(event, context):
    processed_count = 0
    
    print(f"Received event: {json.dumps(event)}")
    
    for record in event['Records']:
        try:
            # Parse the message from SQS
            body = json.loads(record['body'])
            print(f"Parsed SQS message body: {json.dumps(body)}")
            
            message = json.loads(body['Message'])
            print(f"Extracted SNS message: {json.dumps(message)}")
            
            # Process only if it's a transaction message
            if 'transaction_id' in message:
                print(f"Processing transaction: {message['transaction_id']}")
                
                # Extract order information
                order_data = {
                    "transaction_id": message["transaction_id"],
                    "timestamp": message["timestamp"],
                    "customer_id": message["customer_id"],
                    "items": message["items"],
                    "total_amount": message["total_amount"],
                    "payment_method": message["payment_method"]
                }
                
                # Add order processing details
                order_data["processing_timestamp"] = context.invoked_function_arn
                order_data["status"] = "processed"
                order_data["fulfillment_center"] = assign_fulfillment_center(message["shipping_address"]["state"])
                
                # Calculate metrics
                order_data["item_count"] = sum(item["quantity"] for item in message["items"])
                order_data["avg_item_price"] = message["total_amount"] / order_data["item_count"]
                
                print(f"Prepared order data for EventBridge: {json.dumps(order_data)}")
                
                # Send to EventBridge
                print(f"Sending to EventBridge with source='com.ecommerce.orders', detailType='order_processed'")
                response = send_to_eventbridge(order_data, "order_processed")
                print(f"EventBridge response: {json.dumps(response)}")
                processed_count += 1
                
        except Exception as e:
            print(f"Error processing record: {str(e)}")
            import traceback
            print(f"Traceback: {traceback.format_exc()}")
    
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": f"Processed {processed_count} orders successfully"
        })
    }

def send_to_eventbridge(data, detail_type):
    """Send data to EventBridge"""
    try:
        entry = {
            'Source': 'com.ecommerce.orders',
            'DetailType': detail_type,
            'Detail': json.dumps(data),
            'EventBusName': EVENT_BUS_NAME
        }
        print(f"EventBridge entry: {json.dumps(entry)}")
        
        response = events.put_events(
            Entries=[entry]
        )
        return response
    except Exception as e:
        print(f"Error sending to EventBridge: {str(e)}")
        import traceback
        print(f"Traceback: {traceback.format_exc()}")
        raise e

def assign_fulfillment_center(state):
    """Assign an order to a fulfillment center based on the shipping state"""
    # East coast states
    east_coast = ["NY", "NJ", "PA", "MA", "CT", "RI", "NH", "ME", "VT", "DE", "MD", "VA", "NC", "SC", "GA", "FL"]
    # West coast states
    west_coast = ["CA", "OR", "WA", "NV", "AZ"]
    # Central states
    central = ["TX", "OK", "KS", "NE", "SD", "ND", "MN", "IA", "MO", "AR", "LA", "MS", "AL", "TN", "KY", "WV", "OH", "IN", "IL", "MI", "WI"]
    
    if state in east_coast:
        return "fc_east_001"
    elif state in west_coast:
        return "fc_west_001"
    else:  # central or any other
        return "fc_central_001"
